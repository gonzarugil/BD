RSS_URL = 'http://www.theguardian.com/world/rss'

POS_LEX = 'resources/wh-positive-words.txt'
NEG_LEX = 'resources/wh-negative-words.txt'

STEMMING = False
